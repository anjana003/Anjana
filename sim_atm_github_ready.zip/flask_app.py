from flask import Flask, render_template_string, request, jsonify, send_from_directory
import uuid, time, os

app = Flask(__name__)

# In-memory store of issued transactions
transactions = {}

# Ensure 'static/qr' exists to store QR images
QR_DIR = os.path.join(os.path.dirname(__file__), 'static', 'qr')
os.makedirs(QR_DIR, exist_ok=True)

ATM_PAGE = """<!doctype html>
<html>
  <head><meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Simulated ATM</title>
    <style>
      body { font-family: Arial; max-width:600px; margin: 20px auto; }
      .qr { font-family: monospace; background:#f3f3f3; padding:12px; border-radius:6px; }
      .button { padding:10px 14px; background:#1976d2; color:white; border:none; border-radius:6px; cursor:pointer; }
      img.atm-qr { width:260px; height:auto; border: 2px solid #ddd; border-radius:8px; display:block; margin:10px 0; }
    </style>
  </head>
  <body>
    <h2>Simulated ATM</h2>
    <p><strong>Transaction ID:</strong> {{ tx_id }}</p>
    <p><strong>QR Payload (copy or scan):</strong></p>
    <div class="qr" id="qr">{{ payload }}</div>
    {% if qr_url %}
      <p><strong>QR Image (scan with phone camera)</strong></p>
      <img src="{{ qr_url }}" class="atm-qr" alt="ATM QR code">
    {% endif %}
    <p><strong>Amount:</strong> ₹{{ amount }}</p>
    <p><strong>Expires in:</strong> <span id="ttl">120</span>s</p>
    <button class="button" onclick="regenerate()">Generate new QR</button>
    <h3>Transaction log</h3>
    <pre id="log">{{ log }}</pre>
    <script>
      var ttl = 120;
      setInterval(function() {
        ttl -= 1;
        if(ttl < 0) ttl = 0;
        document.getElementById('ttl').innerText = ttl;
      }, 1000);
      function regenerate(){
        fetch('/atm/new', {method:'POST'}).then(r=>r.json()).then(d=>location.reload());
      }
      // refresh log every 3s
      setInterval(()=>fetch('/atm/log').then(r=>r.text()).then(t=>document.getElementById('log').innerText=t), 3000);
    </script>
  </body>
</html>"""

@app.route('/')
def index():
    return "Open /atm to view simulated ATM."

@app.route('/atm')
def atm():
    # Show last created tx or create one
    if not transactions:
        tx_id, payload, amount, qr_filename = create_transaction()
    else:
        tx_id = list(transactions.keys())[-1]
        payload = transactions[tx_id]['payload']
        amount = transactions[tx_id]['amount']
        qr_filename = transactions[tx_id].get('qr_file')
    qr_url = f'/static/qr/{qr_filename}' if qr_filename else None
    log = "\n".join([f"{k} | {v['status']} | {v['amount']} | {v['phone'] or '-'} | {v['time']}" for k,v in transactions.items()])
    return render_template_string(ATM_PAGE, tx_id=tx_id, payload=payload, amount=amount, log=log, qr_url=qr_url)

def create_transaction(amount=500):
    tx_id = str(uuid.uuid4())
    payload = f"SIMATM|tx:{tx_id}|amount:{amount}|ts:{int(time.time())}"
    qr_filename = None

    # Try to generate QR PNG if qrcode library is available.
    try:
        import qrcode
        img = qrcode.make(payload)
        qr_filename = f"{tx_id}.png"
        path = os.path.join(QR_DIR, qr_filename)
        img.save(path)
    except Exception as e:
        # If qrcode isn't installed or generation fails, we'll skip the image but keep the payload text.
        print("[SIMATM] QR generation skipped:", e)
        qr_filename = None

    transactions[tx_id] = {
        'payload': payload,
        'amount': amount,
        'status': 'issued',
        'phone': None,
        'time': time.strftime("%Y-%m-%d %H:%M:%S"),
        'qr_file': qr_filename
    }
    return tx_id, payload, amount, qr_filename

@app.route('/atm/new', methods=['POST'])
def atm_new():
    tx_id, payload, amount, qr_filename = create_transaction()
    return jsonify({'tx_id': tx_id, 'payload': payload, 'amount': amount, 'qr_file': qr_filename})

@app.route('/atm/log')
def atm_log():
    return "\n".join([f"{k} | {v['status']} | {v['amount']} | {v['phone'] or '-'} | {v['time']}" for k,v in transactions.items()])

@app.route('/withdraw', methods=['POST'])
def withdraw():
    """
    Expected JSON:
    {
      "payload": "SIMATM|tx:...|amount:...|ts:...",
      "phone": "user-phone",
      "pin": "1234"
    }
    """
    data = request.get_json()
    if not data or 'payload' not in data:
        return jsonify({'ok': False, 'reason': 'missing payload'}), 400

    payload = data['payload']
    # parse tx id
    try:
        parts = dict(x.split(':',1) for x in payload.split('|') if ':' in x)
        tx_part = parts.get('tx')
        amount = parts.get('amount')
    except Exception:
        return jsonify({'ok': False, 'reason': 'invalid payload format'}), 400

    if tx_part not in transactions:
        return jsonify({'ok': False, 'reason': 'unknown or expired transaction'}), 404

    tx = transactions[tx_part]
    # simulate PIN check (for demo accept any 4-digit)
    pin = data.get('pin','')
    if len(pin) != 4 or not pin.isdigit():
        return jsonify({'ok': False, 'reason': 'invalid pin format (use 4 digits)'}), 403

    # simulate authorization and dispense
    if tx['status'] != 'issued':
        return jsonify({'ok': False, 'reason': 'transaction already used or invalid'}), 409

    tx['status'] = 'dispensed'
    tx['phone'] = data.get('phone')
    tx['time'] = time.strftime("%Y-%m-%d %H:%M:%S")

    # simulate "dispense": here we just log and return success
    print(f"[SIMATM] Dispensed ₹{tx['amount']} for tx {tx_part} to phone {tx['phone']}")
    return jsonify({'ok': True, 'message': f"Simulated dispense of ₹{tx['amount']}"})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
