# Requires Appium-Python-Client and a running Appium server + Android emulator/browser
from appium import webdriver
import time

caps = {
    "platformName": "Android",
    "platformVersion": "12",           # set to your emulator version
    "deviceName": "emulator-5554",
    "browserName": "Chrome",
    "automationName": "UiAutomator2"
}

driver = webdriver.Remote("http://localhost:4723/wd/hub", caps)
# open phone client URL (replace with actual IP)
driver.get("http://YOUR_PC_LOCAL_IP:5000/static/phone_client_with_camera_qr.html")
time.sleep(2)

# fill payload, phone, pin then submit via JS if needed
payload = "SIMATM|tx:REPLACE_WITH_TX|amount:500|ts:0"
driver.execute_script("document.getElementById('payload').value = arguments[0];", payload)
driver.execute_script("document.getElementById('phone').value = arguments[0];", "+919876543210")
driver.execute_script("document.getElementById('pin').value = arguments[0];", "1234")
driver.execute_script("document.getElementById('submit').click();")
time.sleep(3)
print(driver.page_source)
driver.quit()
