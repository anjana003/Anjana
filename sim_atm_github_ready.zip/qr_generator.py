# optional: requires `pip install qrcode pillow`
import qrcode
import sys

payload = sys.argv[1] if len(sys.argv) > 1 else "SIMATM|tx:example|amount:500|ts:0"
img = qrcode.make(payload)
img.save("sim_atm_qr.png")
print("Saved sim_atm_qr.png with payload:", payload)
