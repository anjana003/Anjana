# sim_atm_demo - Simulated ATM with Phone QR Scanner

This project is a **safe, local simulation** of an ATM <-> phone workflow. It **does not** interact with any real banking networks or cash-dispensing hardware — it only simulates the flow for testing and demos.

## Included files
- `flask_app.py` - Flask server that serves the ATM page and `/withdraw` endpoint.
- `static/phone_client.html` - simple phone client (paste QR payload).
- `static/phone_client_with_camera_qr.html` - phone client with camera-based QR scanner (uses html5-qrcode CDN).
- `qr_generator.py` - optional script to create a QR PNG (requires `qrcode` and `Pillow`).
- `appium_test.py` - optional Appium script to automate the phone client in an Android emulator.
- `README.md` - this file (how to run).

## Quick start (Python 3.8+)
1. Create & activate a virtualenv:
   ```bash
   python3 -m venv venv
   source venv/bin/activate   # Windows: venv\Scripts\activate
   ```
2. Install dependencies:
   ```bash
   pip install Flask qrcode pillow
   ```
3. Place static files (already provided) in `static/` and run the server:
   ```bash
   python flask_app.py
   ```
   The server will bind to port 5000 on all interfaces (`0.0.0.0`), so other devices on your LAN can access it.

4. On the machine running the server:
   - Open ATM page: `http://localhost:5000/atm`
   - The page shows a generated QR payload (text).

5. On a phone (same Wi‑Fi network):
   - Open the camera-enabled phone client: `http://<PC_LOCAL_IP>:5000/static/phone_client_with_camera_qr.html`
   - Allow camera permission, press **Start Scanner**, and point at the QR payload displayed on the ATM page.
   - After scanning, the payload field will auto-fill. Enter phone number and a 4-digit PIN (any 4 digits accepted in demo), then press **Send Withdraw Request**.
   - The ATM page log will show the transaction status change to `dispensed` and the Flask console prints a simulated dispense message.

## Notes & troubleshooting
- If your phone can't reach your PC: ensure firewall allows inbound on port 5000 and use the PC's LAN IP (not `localhost`). Use `ipconfig` / `ifconfig` to find it.
- If camera access fails, ensure you're using HTTPS or a localhost-like origin on some browsers. If you're serving over LAN HTTP and camera access is blocked by the browser, try using Chrome on Android which generally allows camera for HTTP on local networks, or use `ngrok http 5000` and serve over the forwarded HTTPS URL.
- To generate a QR PNG for easier scanning, run:
  ```bash
  python qr_generator.py "SIMATM|tx:<replace>|amount:500|ts:0"
  ```
- Appium: edit `appium_test.py` to match your emulator and server IP, start Appium server, then run the script.

## License / Safety
This project is for educational and testing purposes only. Do not connect it to real ATMs, bank accounts, or any cash-dispensing devices.
