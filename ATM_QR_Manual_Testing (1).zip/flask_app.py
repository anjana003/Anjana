from flask import Flask, request, jsonify, render_template_string, send_file
import qrcode, os, io, json
from datetime import datetime

app = Flask(__name__)

# In-memory session storage
sessions = {}

HTML = '''
<!DOCTYPE html>
<html>
<head><title>ATM QR Simulator</title></head>
<body>
  <h1>ATM QR Simulator</h1>
  <form method="post" action="/generate">
    <label>Amount (₹):</label>
    <input name="amount" required/>
    <button type="submit">Generate QR</button>
  </form>
  {% if session_id %}
  <h3>Generated QR:</h3>
  <img src="/qr/{{ session_id }}.png" width="200"/><br/>
  <b>Session:</b> {{ session_id }}<br/>
  <b>Amount:</b> ₹{{ amount }}
  {% endif %}
  <hr>
  <h3>Transactions</h3>
  <a href="/transactions">View All</a>
</body>
</html>
'''

@app.route("/", methods=["GET", "POST"])
def index():
    session_id = None
    amount = None
    if request.method == "POST":
        amount = request.form["amount"]
        session_id = str(int(datetime.now().timestamp()))
        payload = {"session_id": session_id, "amount": amount, "ts": datetime.now().isoformat()}
        sessions[session_id] = {"status": "PENDING", "amount": amount, "created": datetime.now().isoformat()}
        img = qrcode.make(json.dumps(payload))
        os.makedirs("qr", exist_ok=True)
        img.save(f"qr/{session_id}.png")
    return render_template_string(HTML, session_id=session_id, amount=amount)

@app.route("/qr/<sid>.png")
def serve_qr(sid):
    return send_file(f"qr/{sid}.png", mimetype="image/png")

@app.route("/scan", methods=["POST"])
def scan():
    data = request.get_json(force=True)
    sid = data.get("session_id")
    otp = data.get("otp")
    if not sid or sid not in sessions:
        return jsonify({"error": "invalid_session"}), 404
    if otp != "123456":
        sessions[sid]["status"] = "FAILED"
        return jsonify({"error": "invalid_otp"}), 403
    sessions[sid]["status"] = "DISPENSED"
    sessions[sid]["account"] = data.get("account")
    sessions[sid]["otp"] = otp
    sessions[sid]["completed"] = datetime.now().isoformat()
    return jsonify({"status": "ok", "txn": sessions[sid]})

@app.route("/transactions")
def txns():
    return jsonify(sessions)

@app.route("/status/<sid>")
def status(sid):
    return jsonify({"session": sessions.get(sid)})

if __name__ == "__main__":
    app.run(debug=True)
