# ATM QR Manual Testing Simulator

This package contains a lightweight demo of an **ATM QR withdrawal flow** for manual testing.

## Files
- `flask_app.py` — Runs the ATM simulator server.
- `phone_client.html` — A phone-side page to submit scan payloads manually.

## Prerequisites
- Python 3.8+
- Install required packages:
  ```bash
  pip install flask qrcode pillow pyzbar requests
  ```

## Run ATM Simulator
1. Activate your Python venv (optional).
2. Start Flask server:
   ```bash
   python flask_app.py
   ```
3. Open in browser: [http://127.0.0.1:5000](http://127.0.0.1:5000)

## Manual Testing Steps
1. Generate a QR with an amount.
2. Scan the QR from your phone camera (or save and decode it).
3. Open `phone_client.html` in your phone browser.
   - Serve it from PC:
     ```bash
     python -m http.server 8000
     ```
     Then open `http://<PC_IP>:8000/phone_client.html` on your phone (same Wi-Fi).
4. Paste the QR JSON or session_id and click **Send /scan**.
5. Check the ATM browser — the transaction should show **DISPENSED**.

## Expected Behavior
- OTP `123456` → Success (`status: DISPENSED`)
- Any other OTP → Fail (`status: FAILED`)

Enjoy testing!
